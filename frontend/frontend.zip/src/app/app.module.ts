import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { EditEventComponent } from './main-page/edit-event/edit-event.component';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, NgModel } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { MatSliderModule } from '@angular/material/slider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatTableModule } from '@angular/material/table';
import {MatDialogModule} from '@angular/material/dialog';


import { CreateEventComponent } from './main-page/create-event/create-event.component';
import { DeleteEventComponent } from './main-page/delete-event/delete-event.component';
import { UsersComponent } from './main-page/users/users.component';
import { routing } from './app.routing';
import { MainPageComponent } from './main-page/main-page.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { SignUpFormComponent } from './sign-up-form/sign-up-form.component';
import { AppComponent } from './app.component';
import { EventService } from './event.service'
import { HttpClientModule } from '@angular/common/http';

import{ FullCalendarModule } from 'primeng/fullcalendar';
import { CalendarComponent } from './components/calendar/calendar.component';
import { AddEventButtonComponent, AddEventButtonDialog } from './components/add-event-button/add-event-button.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    SignUpFormComponent,
    MainPageComponent,
    DeleteEventComponent,
    UsersComponent,
    CreateEventComponent,
    EditEventComponent,
    CalendarComponent,
    AddEventButtonComponent,
    AddEventButtonDialog


  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    FlexLayoutModule,
    MatSliderModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    routing,
    HttpClientModule,
    MatCardModule,
    MatNativeDateModule,
    MatListModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatToolbarModule,
    MatSidenavModule,
    MatTableModule,
    FontAwesomeModule,
    FullCalendarModule,
    MatDialogModule,

  ],
  providers: [EventService,],
  bootstrap: [AppComponent]
})
export class AppModule { }
