import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent implements OnInit {

  loginForm: FormGroup = new FormGroup({});
  usernameError: string = "";
  passwordError: string = "";
  loginClicked: boolean = false;
  userE: boolean = false;
  constructor(private fBuilder: FormBuilder, private router: Router, private userService: UserService) {



  }

  ngOnInit(): void {
    this.loginForm = this.fBuilder.group({

      username: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.required])
    })
  }

  onLogin(): void {
    this.loginClicked = true;
    this.userService.getUserByUsername(this.loginForm
      .value).toPromise()
      .then(() => {
        this.router.navigate(['']);
      }).catch((err) => {
        if (err.status === 404) {
          this.usernameError = err.error;
          console.log(this.usernameError);
        }
        else{
          this.passwordError = err.error;
          console.log(this.usernameError);
        }
      })

    // console.log(this.loginForm.value);

  }

  get f(){
    return this.loginForm.controls
  }

}
