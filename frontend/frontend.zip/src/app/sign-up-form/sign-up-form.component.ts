import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-sign-up-form',
  templateUrl: './sign-up-form.component.html',
  styleUrls: ['./sign-up-form.component.scss']
})
export class SignUpFormComponent implements OnInit {

  myForm: FormGroup = new FormGroup({});
  teams: string [] = ['Team 1', 'Team 2', 'Team 3'];
  usernameError: string = "";
  showUserNameError = true;
  constructor(private userService: UserService, private router: Router) { }

  ngOnInit(): void {

    this.myForm = new FormGroup({
      'id' : new FormControl(null,Validators.required),
      'email': new FormControl(null, [
        Validators.required,
        Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9]*[a-z0-9])?")
      ]),
      'username': new FormControl(null, Validators.required),
      'teamId': new FormControl(null, Validators.required),
      'password': new FormControl(null, Validators.required),
      'event': new FormControl(null,Validators.required),
    })



  }

  onSubmit() {


    // console.log(this.myForm.value);
    this.userService.addUser(
      0,
      this.myForm.controls['email'].value,
      this.myForm.controls['username'].value,
      this.myForm.controls['teamId'].value,
      this.myForm.controls['password'].value,
      [],
    ).toPromise()
    .then(()=> {
      this.router.navigate(['']);
    })
    .catch((err) => {
      this.usernameError = err.error;
      console.log(this.usernameError);
    });


  }









}

// [a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9]*[a-z0-9])?
