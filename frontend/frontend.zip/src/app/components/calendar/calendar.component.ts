import { Component, OnInit } from '@angular/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import {USERS} from 'src/app/mock-db/mock-users'
import { UserService } from 'src/app/user.service';
import { AnyArray } from 'mongoose';
import { UserModel } from 'src/app/mock-db/userModel';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css']
})

export class CalendarComponent implements OnInit {
  public events: Array<any>=[];
  public options: any;
  public users: any    // mock-users   : frontend "static"

  constructor(private userServece:UserService) { }
  ngOnInit(): void {
    this.userServece.getUsers().subscribe((userList)=>{
      this.users = userList
    });
    console.log(this.users);
    this.options = {
      plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
      defaultDate: new Date(),
      header: {
        left: 'prev,next',
        center: 'title',
        right: 'dayGridMonth'
      }
    }

     /* this.users.forEach((user) => {
        user.event.forEach(event => {
          this.events.push({
          title: (event.title + ' : '+ user.username) ,
          start:event.start,
          end: event.end,
          backgroundColor: event.backgroundColor,
          editable:true,
          allDay: true,
         })
      });
    }); */
    console.log(this.users);
    console.log(this.events);
  }

}
