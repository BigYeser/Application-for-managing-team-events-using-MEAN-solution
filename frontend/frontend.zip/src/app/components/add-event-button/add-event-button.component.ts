import { Component, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
export interface DialogData {
  animal: string;
  name: string;
}

/**
 * @title Dialog Overview
 */

@Component({
  selector: 'app-add-event-button',
  templateUrl: './add-event-button.component.html',
  styleUrls: ['./add-event-button.component.css']
})
export class AddEventButtonComponent {
  animal: string = '';
  name: string = '';

  constructor(public dialog: MatDialog) { }
  openDialog(): void {
    const dialogRef = this.dialog.open(AddEventButtonDialog, {
      width: '250px',
      data: { name: this.name, animal: this.animal },
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
      this.animal = result;
    });
  }
}
@Component({
  selector: 'add-event-button-dialog',
  templateUrl: 'add-event-button-dialog.html',
})
export class AddEventButtonDialog{
  constructor(
    public dialogRef: MatDialogRef<AddEventButtonDialog>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
  ) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
