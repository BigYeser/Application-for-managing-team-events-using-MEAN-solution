import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CalendarEvent } from './mock-db/eventModel';

@Injectable({
  providedIn: 'root'
})
export class EventService {

  uri = 'http://localhost:3000'

  constructor(private http: HttpClient) { }

  getEvents() {
    return this.http.get(`${this.uri}/api/events`);
  }

  getEventByID(id: any) {
    return this.http.get(`${this.uri}/api/event/${id}`);
  }

  addEvent(eventTitle: string, startDate: Date,endDate: Date, description: string, visibility: "Public" | "Private") {
    const event: CalendarEvent = {
      eventTitle,
      startDate,
      endDate,
      description,
      isPublic: visibility === "Public"
    };
    return this.http.post(`${this.uri}/api/events`, event);

  }

  updateEvent(id: any ,eventTitle: string, startDate: Date,endDate: Date, description: string, visibility: "Public" | "Private") {
    const event: CalendarEvent = {
      eventTitle,
      startDate,
      endDate,
      description,
      isPublic: visibility === "Public"
    };
    return this.http.put(`${this.uri}/api/event/${id}`, event);

  }

  deleteEvent(id: any){
    return this.http.delete(`${this.uri}/api/event/${id}`)
  }

  deleteEvents(){
    return this.http.delete(`${this.uri}/api/events`)
  }

}
