
export interface CalendarEvent {
  id?: number;
  eventTitle: string;
  startDate: Date;
  endDate: Date;
  description: string;
  isPublic: boolean;
  userId?: number;
}
