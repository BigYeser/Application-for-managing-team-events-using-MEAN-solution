import {CalendarEvent} from './eventModel';


 export const EVENTS: CalendarEvent[] = [
  {
    id:1,
    userId: 1,
    eventTitle: '',
    startDate: new Date(),
    endDate: new Date(),
    description: '',
    isPublic: true,
  },
  {
    id:2,
    userId: 2,
    eventTitle: '',
    startDate: new Date(),
    endDate: new Date(),
    description: '',
    isPublic: true,
  },
  {
    id:3,
    userId: 2,
    eventTitle: '',
    startDate: new Date(new Date().getTime() + (24 * 60 * 60 * 1000)),
    endDate: new Date(),
    description: '',
    isPublic: true,
  }
 ]

