import {UserModel} from './userModel';

export const USERS: UserModel [] = [
  {
    id: 1,
    email: 'ahmad@gmail.com',
    password: 'ahmad123',
    username: 'Ahmad',
    teamId: '1',
    event:[
      {
        title:"event1",
        start:new Date(new Date().getTime()),
        end:new Date(new Date().getTime() + (4*60*60*1000)),
        userId:'1',
        desctiption:'',
        backgroundColor: "#ff0000",
        isPrivate:false,
      },
      {
        title:"event2",
        start:new Date(new Date().getTime() + (72 * 60*60*1000 )),
        end:new Date(new Date().getTime() + (72 * 60*60*1000 * 2)),
        userId:'1',
        desctiption:'',
        backgroundColor: "#ff0000",
        isPrivate:true,
      }]
  },
  {
    id: 2,
    email: 'abd@gmail.com',
    password: 'abd123',
    username: 'Abd',
    teamId: '1',
    event:[],
  },
  {
    id: 3,
    email: 'osama@gmail.com',
    password: 'osama123',
    username: 'Osama',
    teamId: '2',
    event:[
      {
        title: "event1",
        start: new Date(new Date().getTime()),
        end: new Date(new Date().getTime() + (2*60*60*1000)),
        userId:'3',
        backgroundColor: "#000",
        isPrivate:true,
        desctiption:''
      }

    ]
  },
]

