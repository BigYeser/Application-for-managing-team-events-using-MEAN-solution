export interface UserModel {
  id?: number;
  email: string;
  username: string;
  password: string;
  teamId: string;
  event:Array<{
    title: string,
    start: Date,
    end: Date,
    userId:string,
    desctiption:string,
    isPrivate:boolean,
    backgroundColor: string,
  }>,
}
