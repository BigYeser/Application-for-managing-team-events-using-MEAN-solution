import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { UserModel } from './mock-db/userModel';





@Injectable({
  providedIn: 'root'
})
export class UserService {

  uri = 'http://localhost:3000'

  constructor(private http: HttpClient) { }



  getUsers() {
    return this.http.get(`${this.uri}/api/users`);
  }

  getUserByUsername(user: UserModel) {
    return this.http.post(`${this.uri}/api/login`, user);
  }

  addUser(id: number , email: string, username: string, teamId: string, password: string , event: Array<any>) {
    const User: UserModel = {
      id,
      username,
      email,
      teamId,
      password,
      event
    }
    return this.http.post(`${this.uri}/api/signup`, User);
  }



}
