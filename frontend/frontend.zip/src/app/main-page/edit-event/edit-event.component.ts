import { Component, OnInit } from '@angular/core';
import { EventService } from '../../event.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-edit-event',
  templateUrl: './edit-event.component.html',
  styleUrls: ['./edit-event.component.scss']
})
export class EditEventComponent implements OnInit {

  eventForm: FormGroup = new FormGroup({});
  visibilityStates: string [] = ['Private', 'Public'];
  listEvents: any;
  selectedEvent: any;

constructor(private fb: FormBuilder, private eventService: EventService){


  this.eventService.getEvents().subscribe((events)=>{

    this.listEvents = events;
    });

}

ngOnInit(): void {

  this.eventForm = new FormGroup({

    'eventTitle': new FormControl(null, Validators.required),
    'startDate': new FormControl(null, Validators.required),
    'endDate': new FormControl(null, Validators.required),
    'description': new FormControl(null),
    'isPublic': new FormControl('Private')
  })

}


showDateFormat(date: Date): string{
  return new Date(date).toLocaleDateString('de-DE', {
    year:'numeric',
    month:'2-digit',
    day:'2-digit'
  })
}
 formatDate(date: Date) {
  var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

  if (month.length < 2)
      month = '0' + month;
  if (day.length < 2)
      day = '0' + day;

  return [year, month, day].join('-');
}

onSelect(selectedEvent: any): void {
  console.log(selectedEvent)
  this.eventForm = new FormGroup({

    'eventTitle': new FormControl(selectedEvent.eventTitle, Validators.required),
    'startDate': new FormControl(this.formatDate(selectedEvent.startDate), Validators.required),
    'endDate': new FormControl(this.formatDate(selectedEvent.endDate), Validators.required),
    'description': new FormControl(selectedEvent.description),
    'isPublic': new FormControl(selectedEvent.isPublic, Validators.required)
  })

  this.selectedEvent = selectedEvent;

}


onSubmit() {
  this.eventService.updateEvent(this.selectedEvent._id,
    this.eventForm.controls['eventTitle'].value,
    this.eventForm.controls['startDate'].value,
    this.eventForm.controls['endDate'].value,
    this.eventForm.controls['description'].value,
    this.eventForm.controls['isPublic'].value
  ).subscribe(() => {

  })
}

}
