import { Component, OnInit } from '@angular/core';
// import { USERS } from '../../mock-db/mock-users';
// import { User } from '../../mock-db/userModel';
import { UserService } from '../../user.service'


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  listUsers: any = [];


  constructor(private userService: UserService) { }

  ngOnInit(): void{
  this.userService.getUsers().subscribe(users =>{
    this.listUsers = users;
  })
  }

}
