import { Component, Input, OnInit } from '@angular/core';
import { EventService } from '../../event.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
// import { EVENTS } from '../../mock-db/mock-events';
import { faTimes } from '@fortawesome/free-solid-svg-icons';



@Component({
  selector: 'app-delete-event',
  templateUrl: './delete-event.component.html',
  styleUrls: ['./delete-event.component.scss']
})
export class DeleteEventComponent implements OnInit {
  faTimes = faTimes;
  eventForm: FormGroup = new FormGroup({});
  listEvents: any;
  noEvents: boolean = false;


  constructor(private fb: FormBuilder, private eventService: EventService) {


  }

  ngOnInit(): void {
    // if (this.listEvents.) {
    //     this.noEvents = true;
    // }
    // console.log(this.listEvents);


    this.eventService.getEvents().subscribe((events)=>{

    this.listEvents = events;
    });


  }

  onSelect(listEvent: any): void {
    console.log("ww", listEvent)

  }


  onDelete(_id: any) {
    confirm("sure to delete the Event?")
    this.listEvents.splice(_id-1, 1)
    this.eventService.deleteEvent(_id).subscribe(()=>{

    })
  }

  showDateFormat(date: Date): string{
    return new Date(date).toLocaleDateString('de-DE', {
      year:'numeric',
      month:'2-digit',
      day:'2-digit'
    })
  }



}
