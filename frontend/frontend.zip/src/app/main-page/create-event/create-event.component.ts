import { EventService } from '../../event.service';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.component.html',
  styleUrls: ['./create-event.component.scss']
})


export class CreateEventComponent implements OnInit {


  eventForm: FormGroup = new FormGroup({});
  states: string [] = ['Private', 'Public'];


constructor(private eventService: EventService){


}

ngOnInit() {

  this.eventForm = new FormGroup({

    'eventTitle': new FormControl(null, Validators.required),
    'startDate': new FormControl(null, Validators.required),
    'endDate': new FormControl(null, Validators.required),
    'description': new FormControl(null),
    'state': new FormControl('Private',Validators.required)
  })
  this.eventService.getEvents().subscribe((events) => {
    // console.log(events)
  })

}

onSave() {

  this.eventService.addEvent(
    this.eventForm.controls['eventTitle'].value,
    this.eventForm.controls['startDate'].value,
    this.eventForm.controls['endDate'].value,
    this.eventForm.controls['description'].value,
    this.eventForm.controls['state'].value
  ).subscribe(() => {

  })

  console.log(this.eventForm.value)
}



}
