import { RouterModule, Routes } from "@angular/router";
import { LoginPageComponent } from "./login-page/login-page.component";
import { MainPageComponent } from "./main-page/main-page.component";
import { SignUpFormComponent } from "./sign-up-form/sign-up-form.component";

const APP_ROUTES: Routes = [
  // { path: '', component: WelcomePageComponent},
  { path: 'login', component: LoginPageComponent},
  { path: 'signup', component: SignUpFormComponent},
  { path: '', component: MainPageComponent},

]


export const routing = RouterModule.forRoot(APP_ROUTES);
